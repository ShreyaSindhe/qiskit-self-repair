// Frontend for the Qiskit self-repair tool. Talks to server.py over a small JSON API.
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const state = { mode: "ask", providers: {}, tasks: [], running: false };

function store(key, value) { try { localStorage.setItem(key, value); } catch (e) {} }
function recall(key) { try { return localStorage.getItem(key); } catch (e) { return null; } }

// ------------------------------------------------------------ backend activity log
let logStart = null;
function log(step, msg, details, cls) {
  const box = $("log");
  const empty = box.querySelector(".log-empty");
  if (empty) empty.remove();
  if (logStart === null) logStart = performance.now();
  const t = ((performance.now() - logStart) / 1000).toFixed(2) + "s";
  const line = document.createElement("div");
  line.className = "log-line";
  let extra = "";
  if (details && Object.keys(details).length) {
    extra = Object.entries(details).map(([k, v]) =>
      `<details><summary>${esc(k)}</summary><pre>${esc(typeof v === "string" ? v : JSON.stringify(v, null, 2))}</pre></details>`).join("");
  }
  line.innerHTML = `<span class="t">${t}</span><span class="s s-${step}">${step.toUpperCase()}</span>` +
    `<span class="m ${cls || ""}">${esc(msg)}${extra}</span>`;
  box.appendChild(line);
  box.scrollTop = box.scrollHeight;
}

// ------------------------------------------------------------ architecture strip
function light(step, outcome) {
  for (const n of ["ui", "api", "llm", "exec"]) $("node-" + n).classList.remove("active", "ok", "fail");
  if (!step) return;
  const node = $("node-" + step);
  if (node) node.classList.add(outcome || "active");
}

// ------------------------------------------------------------ setup
async function init() {
  try {
    const h = await (await fetch("/api/health")).json();
    $("status").textContent = `backend online · Qiskit ${h.qiskit_version}`;
    $("status").className = "pill " + (h.qiskit_version === "unknown" ? "pill-bad" : "pill-ok");
    if (h.qiskit_version === "unknown") $("status").textContent = "backend online · Qiskit NOT installed";
    state.providers = h.providers;
  } catch (e) {
    $("status").textContent = "backend offline: start python server.py";
    $("status").className = "pill pill-bad";
    return;
  }
  const sel = $("provider");
  for (const name of [...Object.keys(state.providers), "mock"]) {
    const o = document.createElement("option");
    o.value = name;
    o.textContent = name === "mock" ? "mock (no key, demo only)" : name;
    sel.appendChild(o);
  }
  sel.value = recall("provider") || "mock";
  if (!sel.value) sel.value = "mock";
  onProvider(true);
  sel.addEventListener("change", () => onProvider(false));
  $("model").addEventListener("change", () => store("model:" + sel.value, $("model").value));

  const ds = (await (await fetch("/api/datasets")).json()).datasets;
  $("dataset").innerHTML = ds.map((d) => `<option>${esc(d)}</option>`).join("");
  if (ds.includes("qiskit_humaneval.jsonl")) $("dataset").value = "qiskit_humaneval.jsonl";
  $("dataset").addEventListener("change", loadTasks);
  $("task").addEventListener("change", showTask);
  await loadTasks();

  document.querySelectorAll(".tab").forEach((b) => b.addEventListener("click", () => switchTab(b.dataset.tab)));
  document.querySelectorAll(".chip").forEach((c) => c.addEventListener("click", () => { $("question").value = c.textContent; }));
  $("run").addEventListener("click", run);
  $("clear-log").addEventListener("click", () => { $("log").innerHTML = ""; logStart = null; });
}

function onProvider(initial) {
  const p = $("provider").value;
  store("provider", p);
  const info = state.providers[p];
  $("model").value = recall("model:" + p) || (info ? info.model : "mock");
  $("model").disabled = p === "mock";
  $("key-wrap").style.display = info && info.key_env ? "" : "none";
  $("apikey").placeholder = info && info.key_set ? `using ${info.key_env} from the server` : (info && info.key_env ? `or set ${info.key_env}` : "");
  $("node-llm-sub").textContent = p === "mock" ? "mock (offline demo)" : `${p} · ${$("model").value}`;
}

async function loadTasks() {
  const r = await (await fetch("/api/tasks?dataset=" + encodeURIComponent($("dataset").value))).json();
  state.tasks = r.tasks || [];
  $("task").innerHTML = state.tasks.map((t, i) =>
    `<option value="${i}">${esc(t.task_id)} · ${esc(t.entry_point)} (${esc(t.difficulty_scale)})</option>`).join("");
  showTask();
}

function showTask() {
  const t = state.tasks[+$("task").value];
  $("task-prompt").textContent = t ? t.prompt : "";
  $("task-test").textContent = t ? t.test : "";
}

function switchTab(tab) {
  document.querySelectorAll(".tab").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
  $("run-view").hidden = tab === "results";
  $("results-view").hidden = tab !== "results";
  if (tab === "results") return loadResults();
  state.mode = tab;
  $("ask-input").hidden = tab !== "ask";
  $("bench-input").hidden = tab !== "bench";
}

// ------------------------------------------------------------ run
async function run() {
  if (state.running) return;
  const body = {
    mode: state.mode,
    provider: $("provider").value,
    model: $("model").value,
    api_key: $("apikey").value,
    max_attempts: +$("attempts").value,
    feedback: $("feedback").value,
  };
  if (state.mode === "ask") body.question = $("question").value;
  else { body.dataset = $("dataset").value; body.task_id = state.tasks[+$("task").value]?.task_id; }

  state.running = true;
  $("run").disabled = true;
  $("run").textContent = "Running…";
  $("attempts-list").innerHTML = "";
  $("final").innerHTML = "";
  $("node-llm-sub").textContent = body.provider === "mock" ? "mock (offline demo)" : `${body.provider} · ${body.model}`;
  if ($("log").querySelector(".log-line")) log("ui", "──────── new run ────────");
  light("ui");
  log("ui", `fetch("POST /api/solve") · streaming response (Server-Sent Events)`,
      { "request body": { ...body, api_key: body.api_key ? "•••• (hidden)" : "" } });

  try {
    const res = await fetch("/api/solve", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: res.statusText }));
      log("error", `HTTP ${res.status}: ${err.error}`, null, "bad");
      showBanner(false, err.error);
      light(null);
      return;
    }
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "";
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf("\n\n")) >= 0) {
        const chunk = buf.slice(0, i);
        buf = buf.slice(i + 2);
        if (chunk.startsWith("data: ")) handle(JSON.parse(chunk.slice(6)));
      }
    }
  } catch (e) {
    log("error", "Connection to backend lost: " + e.message, null, "bad");
    light(null);
  } finally {
    state.running = false;
    $("run").disabled = false;
    $("run").textContent = "▶ Run";
  }
}

function handle(ev) {
  if (ev.type === "log") {
    const cls = ev.stage === "exec_result" ? (ev.msg.startsWith("✓") ? "good" : "bad") : "";
    log(ev.step, ev.msg, ev.details, cls);
    if (ev.stage === "exec_result") light("exec", ev.msg.startsWith("✓") ? "ok" : "fail");
    else light(ev.step);
  } else if (ev.type === "attempt") {
    renderAttempt(ev.attempt);
  } else if (ev.type === "done") {
    log("done", ev.msg, null, ev.solved ? "good" : "bad");
    light(ev.solved ? "exec" : null, ev.solved ? "ok" : undefined);
    showBanner(ev.solved, ev.solved
      ? (ev.attempts === 1 ? "Solved on the first try" : `Solved on attempt ${ev.attempts}: the repair loop fixed it after ${ev.attempts - 1} failure(s)`)
      : `Not solved within ${ev.attempts} attempt(s)`);
  } else if (ev.type === "error") {
    log("error", ev.msg, null, "bad");
    showBanner(false, ev.msg);
    light(null);
  }
}

// ------------------------------------------------------------ rendering
function renderAttempt(a) {
  const div = document.createElement("div");
  div.className = "attempt " + (a.passed ? "pass" : "fail");
  const status = a.passed ? (state.mode === "ask" ? "✓ ran successfully" : "✓ passed all tests") : "✗ " + a.category_label;
  div.innerHTML = `
    <div class="attempt-head"><span>Attempt ${a.number}: ${esc(status)}</span>
      <small>model ${a.llm_seconds}s · run ${a.run_seconds}s</small></div>
    <div class="attempt-body">
      <button class="copy">copy code</button>
      <pre class="code">${esc(a.code || "(no code in reply)")}</pre>
      ${a.passed ? "" : `<div class="err-label">Error sent back to the model:</div><pre class="code err">${esc(a.feedback)}</pre>`}
    </div>`;
  div.querySelector(".copy").addEventListener("click", (e) => {
    navigator.clipboard?.writeText(a.code).then(() => { e.target.textContent = "copied"; });
  });
  $("attempts-list").appendChild(div);
  // only the latest attempt stays open; older ones collapse to keep the page short
  const all = $("attempts-list").querySelectorAll(".attempt");
  all.forEach((el, i) => { el.querySelector(".attempt-body").hidden = i < all.length - 1; });
  all.forEach((el) => { el.querySelector(".attempt-head").onclick = () => { const b = el.querySelector(".attempt-body"); b.hidden = !b.hidden; }; });
  if (a.result) renderResult(a.result);
}

function bars(obj) {
  const entries = Object.entries(obj).sort((x, y) => y[1] - x[1]).slice(0, 16);
  const max = Math.max(...entries.map(([, v]) => v), 1e-9);
  return `<div class="bars">${entries.map(([k, v]) =>
    `<span class="k">|${esc(k)}⟩</span><div class="bar" style="width:${(100 * v / max).toFixed(1)}%"></div><span class="v">${v}</span>`).join("")}</div>`;
}

function renderResult(r) {
  let html = "";
  if (r.kind === "circuit") {
    const ops = Object.entries(r.ops).map(([k, v]) => `${k}×${v}`).join(", ");
    html = `<h3>Result: quantum circuit</h3><div class="meta">${r.qubits} qubits · depth ${r.depth} · ${esc(ops)}</div>
      <pre class="code">${esc(r.drawing)}</pre>` +
      (r.probabilities ? `<h3>Ideal measurement probabilities</h3>${bars(r.probabilities)}` : "");
  } else if (r.kind === "counts") {
    const total = Object.values(r.counts).reduce((s, v) => s + v, 0);
    html = `<h3>Result: measurement counts</h3><div class="meta">${total} shots</div>${bars(r.counts)}`;
  } else if (r.kind === "state") {
    html = `<h3>Result: quantum state probabilities</h3>${bars(r.probabilities)}`;
  } else {
    html = `<h3>Result (${esc(r.type)})</h3><pre class="code">${esc(r.value)}</pre>`;
  }
  $("final").insertAdjacentHTML("beforeend", `<div class="result-card">${html}</div>`);
}

function showBanner(ok, text) {
  $("final").insertAdjacentHTML("afterbegin", `<div class="banner ${ok ? "ok" : "no"}">${esc(text)}</div>`);
}

// ------------------------------------------------------------ results tab
async function loadResults() {
  const box = $("results");
  box.innerHTML = `<div class="empty">Loading…</div>`;
  let r;
  try { r = await (await fetch("/api/results")).json(); } catch (e) { box.innerHTML = `<div class="empty">Could not load results.</div>`; return; }
  if (r.error) { box.innerHTML = `<div class="empty">${esc(r.error)}</div>`; return; }
  if (!r.runs.length) {
    box.innerHTML = `<div class="empty">No results yet. Run <code>python evaluate.py --provider … </code> first (see README).</div>`;
    return;
  }
  const cols = ["run", "tasks", "pass@1 (no repair) %", "with repair %", "gain (pts)", "% of first-try failures fixed", "avg attempts"];
  let html = `<table class="res"><tr>${cols.map((c) => `<th>${esc(c)}</th>`).join("")}</tr>` +
    r.runs.map((row) => `<tr>${cols.map((c) => `<td>${esc(row[c])}</td>`).join("")}</tr>`).join("") + `</table>`;
  html += passAtKChart(r.pass_at_k);
  if (r.fix_rate.length) {
    const fc = ["run", "first_category", "failed on try 1", "fixed later", "fix rate %"];
    html += `<h3>Which errors get fixed?</h3><table class="res"><tr>${fc.map((c) => `<th>${esc(c === "first_category" ? "first-try error" : c)}</th>`).join("")}</tr>` +
      r.fix_rate.map((row) => `<tr>${fc.map((c) => `<td>${esc(row[c])}</td>`).join("")}</tr>`).join("") + `</table>`;
  }
  box.innerHTML = html;
}

function passAtKChart(pak) {
  const runs = Object.keys(pak);
  if (!runs.length) return "";
  const colors = ["#3b5bdb", "#d9820f", "#1b998b", "#c1436d", "#7a5cc7"];
  const ks = [...new Set(runs.flatMap((r) => Object.keys(pak[r]).map(Number)))].sort((a, b) => a - b);
  const W = 720, H = 300, L = 48, R = 230, T = 20, B = 40;
  const x = (k) => L + (ks.length === 1 ? 0 : (k - ks[0]) / (ks.at(-1) - ks[0]) * (W - L - R));
  const y = (v) => T + (1 - v / 100) * (H - T - B);
  let svg = `<h3>Pass rate as more attempts are allowed</h3><svg viewBox="0 0 ${W} ${H}" style="width:100%;max-width:800px">`;
  for (const v of [0, 25, 50, 75, 100]) svg += `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="#e1e4eb"/><text x="${L - 8}" y="${y(v) + 4}" text-anchor="end" font-size="11" fill="#636b7d">${v}%</text>`;
  for (const k of ks) svg += `<text x="${x(k)}" y="${H - B + 18}" text-anchor="middle" font-size="11" fill="#636b7d">${k}</text>`;
  svg += `<text x="${(L + W - R) / 2}" y="${H - 4}" text-anchor="middle" font-size="11.5" fill="#636b7d">attempts allowed (1 = no repair)</text>`;
  runs.forEach((run, i) => {
    const pts = ks.filter((k) => pak[run][k] != null).map((k) => [x(k), y(pak[run][k]), pak[run][k]]);
    const c = colors[i % colors.length];
    svg += `<polyline fill="none" stroke="${c}" stroke-width="2.2" points="${pts.map((p) => p[0] + "," + p[1]).join(" ")}"/>`;
    pts.forEach((p) => { svg += `<circle cx="${p[0]}" cy="${p[1]}" r="3.5" fill="${c}"/>`; });
    const last = pts.at(-1);
    if (last) svg += `<text x="${last[0] + 8}" y="${last[1] + 4}" font-size="11.5" fill="${c}" font-weight="600">${last[2]}% ${esc(run.slice(0, 28))}</text>`;
  });
  return svg + `</svg>`;
}

init();
