"""Tests for the harness itself. They use plain-Python tasks, so Qiskit is not needed.
Run:  python -m unittest discover tests
"""
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from executor import run_candidate                      # noqa: E402
from llm import MockClient                               # noqa: E402
from prompts import extract_code, feedback_text          # noqa: E402
from repair_loop import solve_task                       # noqa: E402

TASK = {
    "task_id": "toy/0",
    "prompt": 'import math\n\n\ndef add(a, b):\n    """Return a + b."""\n',
    "canonical_solution": "    return a + b\n",
    "test": "def check(candidate):\n    assert candidate(2, 3) == 5\n    assert candidate(-1, 1) == 0\n",
    "entry_point": "add",
    "difficulty_scale": "basic",
}


class Scripted:
    """Fake LLM that returns pre-written replies in order and records what it was sent."""

    def __init__(self, replies):
        self.replies = list(replies)
        self.seen = []

    def chat(self, messages):
        self.seen.append(messages)
        return self.replies.pop(0)


def fence(code):
    return f"Here you go:\n```python\n{code}\n```\nHope this helps."


class ExecutorTests(unittest.TestCase):
    def run_code(self, code, timeout=10):
        return run_candidate(code, TASK["test"], "add", timeout=timeout)

    def test_pass(self):
        r = self.run_code("def add(a, b):\n    return a + b\n")
        self.assertTrue(r.passed)
        self.assertEqual(r.category, "passed")

    def test_wrong_result(self):
        r = self.run_code("def add(a, b):\n    return a - b\n")
        self.assertEqual((r.passed, r.category, r.error_type), (False, "wrong_result", "AssertionError"))

    def test_syntax(self):
        self.assertEqual(self.run_code("def add(a, b)\n    return a + b\n").category, "syntax")

    def test_import_is_api(self):
        r = self.run_code("from math import does_not_exist\ndef add(a, b):\n    return a + b\n")
        self.assertEqual(r.category, "api")
        self.assertIn("does_not_exist", r.error_message)
        self.assertNotIn("/tmp", r.traceback)  # temp paths are hidden from the model

    def test_runtime(self):
        self.assertEqual(self.run_code("def add(a, b):\n    raise ValueError('x')\n").category, "runtime")

    def test_timeout(self):
        r = self.run_code("def add(a, b):\n    while True: pass\n", timeout=2)
        self.assertEqual(r.category, "timeout")


class ExtractTests(unittest.TestCase):
    def test_full_function_gets_prompt_imports(self):
        code = extract_code(fence("def add(a, b):\n    return a + b"), TASK)
        self.assertTrue(code.startswith("import math"))
        self.assertIn("def add", code)

    def test_body_only_is_put_under_signature(self):
        code = extract_code(fence("    return a + b"), TASK)
        self.assertIn('def add(a, b):\n    """Return a + b."""\n    return a + b', code)
        self.assertTrue(run_candidate(code, TASK["test"], "add").passed)

    def test_picks_block_with_the_function(self):
        reply = fence("print('usage')") + "\n" + fence("def add(a, b):\n    return a + b")
        self.assertIn("def add", extract_code(reply, TASK))

    def test_no_code(self):
        self.assertEqual(extract_code("Sorry, I can't help with that.", TASK), "")


class LoopTests(unittest.TestCase):
    def test_repair_after_failure_and_feedback_is_sent(self):
        client = Scripted([fence("def add(a, b):\n    return a - b"),
                           fence("def add(a, b):\n    return a + b")])
        atts = list(solve_task(TASK, client, max_attempts=4, feedback_mode="full"))
        self.assertEqual([a.passed for a in atts], [False, True])
        self.assertEqual(atts[0].category, "wrong_result")
        second_call = client.seen[1]
        self.assertEqual([m["role"] for m in second_call], ["system", "user", "assistant", "user"])
        self.assertIn("AssertionError", second_call[-1]["content"])

    def test_stops_at_max_attempts(self):
        client = Scripted([fence("def add(a, b):\n    return 0")] * 3)
        atts = list(solve_task(TASK, client, max_attempts=3))
        self.assertEqual(len(atts), 3)
        self.assertFalse(atts[-1].passed)

    def test_first_try_pass_makes_one_call(self):
        client = Scripted([fence("def add(a, b):\n    return a + b")])
        self.assertEqual(len(list(solve_task(TASK, client))), 1)

    def test_feedback_modes(self):
        client = Scripted([fence("from math import nope\ndef add(a, b):\n    return a + b")])
        att = next(solve_task(TASK, client, max_attempts=1, feedback_mode="minimal"))
        self.assertTrue(att.feedback.startswith("ImportError"))
        self.assertNotIn("Traceback", att.feedback)
        client = Scripted([fence("from math import nope\ndef add(a, b):\n    return a + b")])
        att = next(solve_task(TASK, client, max_attempts=1, feedback_mode="none"))
        self.assertEqual(att.feedback, "The code did not pass the tests.")

    def test_mock_client_fails_then_fixes(self):
        # MockClient adds `from qiskit import execute`; without qiskit installed this is
        # also an import error, so the behaviour is the same here and on your laptop.
        atts = list(solve_task(TASK, MockClient([TASK]), max_attempts=3))
        self.assertEqual([a.category for a in atts], ["api", "passed"])


class EndToEndTests(unittest.TestCase):
    def test_evaluate_and_analyze(self):
        import analyze
        import evaluate
        with tempfile.TemporaryDirectory() as tmp:
            data = Path(tmp) / "toy.jsonl"
            t2 = dict(TASK, task_id="toy/1", difficulty_scale="intermediate")
            data.write_text(json.dumps(TASK) + "\n" + json.dumps(t2) + "\n")
            for prov in ("mock", "canonical"):
                evaluate.main(["--dataset", str(data), "--provider", prov, "--run", prov,
                               "--out-dir", tmp, "--max-attempts", "3"])
            # resume: rerunning skips finished tasks and adds no lines
            evaluate.main(["--dataset", str(data), "--provider", "mock", "--run", "mock", "--out-dir", tmp])
            self.assertEqual(len((Path(tmp) / "mock.jsonl").read_text().splitlines()), 2)

            df = analyze.load_runs([Path(tmp) / "mock.jsonl", Path(tmp) / "canonical.jsonl"])
            s = analyze.summary_table(df)
            self.assertEqual(s.loc["mock", "pass@1 (no repair) %"], 0.0)
            self.assertEqual(s.loc["mock", "with repair %"], 100.0)
            self.assertEqual(s.loc["canonical", "pass@1 (no repair) %"], 100.0)
            analyze.main([str(Path(tmp) / "mock.jsonl"), str(Path(tmp) / "canonical.jsonl"),
                          "--out", str(Path(tmp) / "rep")])
            for f in ("summary.md", "summary.csv", "pass_at_k.png", "first_try_errors.png", "by_difficulty.png"):
                self.assertTrue((Path(tmp) / "rep" / f).exists(), f)



class AskModeTests(unittest.TestCase):
    def test_free_form_counts_result(self):
        from ask import make_ask_task, parse_result
        task = make_ask_task("return some counts")
        good = fence("def solve():\n    return {'00': 510, '11': 490}")
        atts = list(solve_task(task, Scripted([good]), max_attempts=1))
        self.assertTrue(atts[0].passed)
        r = parse_result(atts[0].stdout)
        self.assertEqual(r["kind"], "counts")
        self.assertEqual(r["counts"], {"00": 510, "11": 490})

    def test_none_result_is_an_error_and_gets_repaired(self):
        from ask import make_ask_task, parse_result
        task = make_ask_task("compute something")
        client = Scripted([fence("def solve():\n    x = 2 + 2"), fence("def solve():\n    return 4")])
        atts = list(solve_task(task, client, max_attempts=3))
        self.assertEqual([a.passed for a in atts], [False, True])
        self.assertIn("returned None", atts[0].error_message)
        self.assertEqual(parse_result(atts[1].stdout), {"type": "int", "kind": "value", "value": "4"})


if __name__ == "__main__":
    unittest.main()
